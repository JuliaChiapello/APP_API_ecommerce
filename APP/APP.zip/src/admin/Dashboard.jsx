function Dashboard() {


    return (
        <div  className='p-6 font-bold text-center text-black '>
            Dashboard      
        </div>
    )
}

export default Dashboard
